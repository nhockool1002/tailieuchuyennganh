@include('common.login.header')
@include('redirect.content')
@include('common.login.footer')

