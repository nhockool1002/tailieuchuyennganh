@include('common.back.header')
@include('common.back.sidebar')
@yield('content')
@include('common.back.footer')