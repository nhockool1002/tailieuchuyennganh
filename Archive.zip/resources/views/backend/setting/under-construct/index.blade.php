@extends('backend.back_layouts')
@section('headname')
	Under Construction Setting
@endsection
@section('content')
	@include('backend.setting.under-construct.content')
@endsection