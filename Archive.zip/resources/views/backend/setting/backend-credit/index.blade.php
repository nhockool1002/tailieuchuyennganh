@extends('backend.back_layouts')
@section('headname')
	Backend Credit Setting
@endsection
@section('content')
	@include('backend.setting.backend-credit.content')
@endsection