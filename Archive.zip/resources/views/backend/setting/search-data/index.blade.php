@extends('backend.back_layouts')
@section('headname')
	Search Data
@endsection
@section('content')
	@include('backend.setting.search-data.content')
@endsection
