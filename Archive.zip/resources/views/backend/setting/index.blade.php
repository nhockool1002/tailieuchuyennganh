@extends('backend.back_layouts')
@section('headname')
	Setting Content
@endsection
@section('content')
	@include('backend.setting.content')
@endsection