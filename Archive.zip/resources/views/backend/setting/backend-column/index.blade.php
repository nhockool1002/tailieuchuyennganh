@extends('backend.back_layouts')
@section('headname')
	Backend Column Setting
@endsection
@section('content')
	@include('backend.setting.backend-column.content')
@endsection