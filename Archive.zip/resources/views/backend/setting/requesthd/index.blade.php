@extends('backend.back_layouts')
@section('headname')
	Request HD
@endsection
@section('content')
	@include('backend.setting.requesthd.content')
@endsection
