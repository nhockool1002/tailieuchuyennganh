@extends('backend.back_layouts')
@section('headname')
	Hashtag List
@endsection
@section('content')
	@include('backend.setting.hashtag.content')
@endsection
