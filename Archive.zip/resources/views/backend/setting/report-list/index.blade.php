@extends('backend.back_layouts')
@section('headname')
	Report View
@endsection
@section('content')
	@include('backend.setting.report-list.content')
@endsection
