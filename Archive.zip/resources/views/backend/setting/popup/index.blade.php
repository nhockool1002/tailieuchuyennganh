@extends('backend.back_layouts')
@section('headname')
	Popup Setting
@endsection
@section('content')
	@include('backend.setting.popup.content')
@endsection