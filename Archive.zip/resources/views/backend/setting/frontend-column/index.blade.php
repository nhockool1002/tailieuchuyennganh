@extends('backend.back_layouts')
@section('headname')
	Frontend Column Setting
@endsection
@section('content')
	@include('backend.setting.frontend-column.content')
@endsection