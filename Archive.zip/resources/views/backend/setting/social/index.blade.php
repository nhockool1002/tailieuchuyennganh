@extends('backend.back_layouts')
@section('headname')
	Social Setting
@endsection
@section('content')
	@include('backend.setting.social.content')
@endsection