@extends('backend.back_layouts')
@section('headname')
	Donate Setting
@endsection
@section('content')
	@include('backend.setting.donate.index.content')
@endsection