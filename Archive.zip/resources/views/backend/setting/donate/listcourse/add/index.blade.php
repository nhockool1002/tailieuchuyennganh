@extends('backend.back_layouts')
@section('headname')
	Thêm khóa học VIP 
@endsection
@section('content')
	@include('backend.setting.donate.listcourse.add.content')
@endsection