@extends('backend.back_layouts')
@section('headname')
	Sửa khóa học VIP 
@endsection
@section('content')
	@include('backend.setting.donate.listcourse.edit.content')
@endsection