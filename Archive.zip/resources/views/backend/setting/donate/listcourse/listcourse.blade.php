@extends('backend.back_layouts')
@section('headname')
	Danh sách khóa học XShare Donate
@endsection
@section('content')
	@include('backend.setting.donate.listcourse.content-listcourse')
@endsection