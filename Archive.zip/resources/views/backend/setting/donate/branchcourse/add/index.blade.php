@extends('backend.back_layouts')
@section('headname')
	Thêm nguồn VIP 
@endsection
@section('content')
	@include('backend.setting.donate.branchcourse.add.content')
@endsection