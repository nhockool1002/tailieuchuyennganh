@extends('backend.back_layouts')
@section('headname')
	Nguồn khóa học VIP
@endsection
@section('content')
	@include('backend.setting.donate.branchcourse.content')
@endsection