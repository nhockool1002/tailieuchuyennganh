@extends('backend.back_layouts')
@section('headname')
@endsection
@section('content')
	@include('backend.setting.donate.branchcourse.edit.content')
@endsection