<div class="donateboxsetting">
   <a href="{{ route('donateSetting') }}" class="btn btn-dark btn-fill">Thông tin Donate</a>
   <a href="{{ route('donateCourseList') }}" class="btn btn-dark btn-fill">Danh sách khóa học</a>
   <a href="{{ route('donateBranchCourse') }}" class="btn btn-dark btn-fill">Nguồn khóa học</a>
</div>