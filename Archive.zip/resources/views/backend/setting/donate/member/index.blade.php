@extends('backend.back_layouts')
@section('headname')
	Danh sách thành viên XShare Donate
@endsection
@section('content')
	@include('backend.setting.donate.member.content')
@endsection