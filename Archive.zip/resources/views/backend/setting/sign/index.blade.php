@extends('backend.back_layouts')
@section('headname')
	Signature Setting
@endsection
@section('content')
	@include('backend.setting.sign.content')
@endsection