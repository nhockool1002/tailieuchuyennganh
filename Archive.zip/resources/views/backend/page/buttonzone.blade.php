								<div class="buttonzone">
                                <a href="{{ route('addPage') }}" class="btn btn-xs btn-warning pull-right"><i class="ti-plus"> Add Page</i></a> 
                                <a href="{{ route('filterPage') }}" class="btn btn-xs btn-success pull-right"><i class="ti-search"> Filter</i></a> 
                                </div>