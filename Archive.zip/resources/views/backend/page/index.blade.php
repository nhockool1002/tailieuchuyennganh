@extends('backend.back_layouts')
@section('headname')
	Page Manager
@endsection
@section('content')
	@include('backend.page.content')
@endsection