    <div class="main-panel">
        @include('common.back.topsetting')
        <div class="content">
            @include('backend.page.main-filter-content')
        </div>
    @include('common.back.copyright')
    </div>