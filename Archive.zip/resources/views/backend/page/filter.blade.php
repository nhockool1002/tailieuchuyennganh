@extends('backend.back_layouts')
@section('headname')
	Filter Page
@endsection
@section('content')
	@include('backend.page.filter-content')
@endsection