@extends('backend.back_layouts')
@section('headname')
	Filter Post
@endsection
@section('content')
	@include('backend.post.filter-content')
@endsection