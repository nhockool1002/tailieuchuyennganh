								<div class="buttonzone">
                                <a href="{{ route('addPost') }}" class="btn btn-xs btn-warning pull-right"><i class="ti-plus"> Add Post</i></a> 
                                <a href="{{ route('filterPost') }}" class="btn btn-xs btn-success pull-right"><i class="ti-search"> Filter</i></a> 
                                </div>