@extends('backend.back_layouts')
@section('headname')
	Posts Manager
@endsection
@section('content')
	@include('backend.post.content')
@endsection