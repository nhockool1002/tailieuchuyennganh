            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="alertbox">
                            @if(count($errors) > 0)
                            <div class="alert alert-danger">
                                @foreach($errors->all() as $err)
                                    <i class="fa fa-times" aria-hidden="true"></i> {{$err}}<br>
                                @endforeach
                            </div>
                            @endif
                            @if(session('success_mesage'))
                                <div class="alert alert-success">
                                    <i class="fa fa-check" aria-hidden="true"></i> {{session('success_mesage')}}
                                </div>
                            @endif
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Filter Post</h4>
                                <p class="category">If you want to filter any post, this tools will help you</p>
                                @include('backend.post.buttonzone')
                            </div>
                            <div class="content table-responsive table-full-width">
                                <div class="col-md-12">
                                    <form method="POST" action="{{ route('postfilterPost') }}">
                                        {{ csrf_field() }}
                                            <div class="form-group">
                                                <label>Filter Post Name</label>
                                                <div class="col-sm-12">
                                                    <div class="row">
                                                        <div class="col-md-5">
                                                            <input type="text" class="form-control border-input" placeholder="Type Post Name" name="postname" value="">
                                                        </div>
                                                        <div class="col-md-5">
                                                            <button type="submit" class="btn btn-success">Filter!</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                    </form>
                                </div>
                                <table class="table table-striped">
                                    <thead>
                                        <th>ID</th>
                                    	<th>Post Title</th>
                                    	<th>Description</th>
                                    	<th>Category</th>
                                        <th>User</th>
                                        <th>Opion</th>
                                    </thead>
                                    <tbody>
                                        @if(isset($posts))
                                        @foreach($posts as $post)
                                        <tr>
                                        	<td>{{ $post->id }}</td>
                                            <td>{{ $post->post_name }}</td>
                                        	<td>{{ getExcerpt($post->post_content, 0, 50) }}</td>
                                            <td>{{ $post->category->cat_name }}</td>
                                        	<td>{{ $post->user->username }}</td>
                                            <td>
                                                <a href="{{ route('editPost', $post->id) }}" class="btn btn-primary"><i class="ti-pencil"></i></a>
                                                <a href="{{ route('deletePost', $post->id) }}" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this item?');"><i class="ti-close"></i></a>
                                            </td>
                                        </tr>
                                        @endforeach
                                        @endif
                                    </tbody>
                                </table>
                                <div class="paginate-page" style="text-align: center">
                                @if(isset($posts)){!! $posts->links() !!} @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
