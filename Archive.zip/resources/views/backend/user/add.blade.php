@extends('backend.back_layouts')
@section('headname')
	Add User
@endsection
@section('content')
	@include('backend.user.add-content')
@endsection