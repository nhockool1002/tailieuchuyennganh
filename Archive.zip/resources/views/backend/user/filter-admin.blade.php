@extends('backend.back_layouts')
@section('headname')
	Filter Administrator
@endsection
@section('content')
	@include('backend.user.filter-admin-content')
@endsection