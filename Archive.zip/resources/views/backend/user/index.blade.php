@extends('backend.back_layouts')
@section('headname')
	Users Manager
@endsection
@section('content')
	@include('backend.user.content')
@endsection