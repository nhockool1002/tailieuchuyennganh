    <div class="main-panel">
        @include('common.back.topsetting')
        <div class="content">
            @include('backend.user.main-filter-admin-content')
        </div>
    @include('common.back.copyright')
    </div>