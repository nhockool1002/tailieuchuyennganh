@extends('backend.back_layouts')
@section('headname')
	Menu Configure
@endsection
@section('content')
	@include('backend.menu.content')
@endsection