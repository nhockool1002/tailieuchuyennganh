@extends('backend.back_layouts')
@section('headname')
	Logs Manager
@endsection
@section('content')
	@include('backend.log.content')
@endsection