    <div class="main-panel">
        @include('common.back.topsetting')
        <div class="content">
            @include('backend.log.main-content')
        </div>
    @include('common.back.copyright')
    </div>