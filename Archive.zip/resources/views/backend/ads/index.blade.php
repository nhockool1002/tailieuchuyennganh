@extends('backend.back_layouts')
@section('headname')
	Advertisement Manager
@endsection
@section('content')
	@include('backend.ads.main-content')
@endsection