								<div class="buttonzone">
                                <a href="{{ route('addViewPokemon') }}" class="btn btn-xs btn-warning pull-right"><i class="ti-plus"> Add ROM</i></a> 
                                </div>
