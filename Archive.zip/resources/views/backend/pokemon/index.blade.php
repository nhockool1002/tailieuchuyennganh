@extends('backend.back_layouts')
@section('headname')
	Pokemon Controller
@endsection
@section('content')
	@include('backend.pokemon.content')
@endsection
