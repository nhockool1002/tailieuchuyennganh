@extends('backend.back_layouts')
@section('headname')
	Category Manager
@endsection
@section('content')
	@include('backend.category.content')
@endsection