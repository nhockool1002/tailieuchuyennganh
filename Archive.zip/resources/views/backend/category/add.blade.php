@extends('backend.back_layouts')
@section('headname')
	Add Category
@endsection
@section('content')
	@include('backend.category.add-content')
@endsection