@include('common.login.header')
@include('login.content')
@include('common.login.footer')

