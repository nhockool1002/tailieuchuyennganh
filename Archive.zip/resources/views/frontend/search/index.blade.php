@extends('frontend.front_layouts')
@section('content')
	@include('frontend.search.breadcrum')
	@include('frontend.search.content')
@endsection