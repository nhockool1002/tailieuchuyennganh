@if(isset($homepage_rightside_300x250_first))
<a href="{{ $homepage_rightside_300x250_first->target_link }}" style="display: inline-block;margin: auto;">
	<img class="img-responsive" src="{{ $homepage_rightside_300x250_first->ads_img }}" alt="" target="_blank">
</a>
@endif
