@if(isset($homepage_rightside_300x250_second))
<a href="{{ $homepage_rightside_300x250_second->target_link }}" style="display: inline-block;margin: auto;">
	<img class="img-responsive" src="{{ $homepage_rightside_300x250_second->ads_img }}" alt="" target="_blank">
</a>
@endif
