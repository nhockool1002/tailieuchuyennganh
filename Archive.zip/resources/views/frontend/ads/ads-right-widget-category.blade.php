@if(isset($category_right_widget_320x250))
    <a href="{{ $category_right_widget_320x250->target_link }}" style="display: inline-block;margin: auto;">
        <img class="img-responsive" src="{{ $category_right_widget_320x250->ads_img }}" alt="" target="_blank">
    </a>
@endif
