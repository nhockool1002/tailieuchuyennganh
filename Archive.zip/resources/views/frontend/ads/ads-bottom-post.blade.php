@if(isset($bottom_post_728x90))
    <a href="{{ $bottom_post_728x90->target_link }}" style="display: inline-block;margin: auto;">
        <img class="img-responsive" src="{{ $bottom_post_728x90->ads_img }}" alt="" target="_blank">
    </a>
@endif
