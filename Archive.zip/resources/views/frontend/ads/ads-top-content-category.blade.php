@if(isset($category_top_content_728x90))
    <a href="{{ $category_top_content_728x90->target_link }}" style="display: inline-block;margin: auto;">
        <img class="img-responsive" src="{{ $category_top_content_728x90->ads_img }}" alt="" target="_blank">
    </a>
@endif
