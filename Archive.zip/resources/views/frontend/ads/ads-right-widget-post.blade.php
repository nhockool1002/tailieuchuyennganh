{{--@if(isset($bottom_right_widget_post_320x250))--}}
    {{--<a href="{{ $bottom_right_widget_post_320x250->target_link }}" style="display: inline-block;margin: auto;">--}}
        {{--<img class="img-responsive" src="{{ $bottom_right_widget_post_320x250->ads_img }}" alt="" target="_blank">--}}
    {{--</a>--}}
{{--@endif--}}
<div class="fb-page" data-href="https://www.facebook.com/tailieuchuyennganhmienphi" data-tabs="" data-width="" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/tailieuchuyennganhmienphi" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/tailieuchuyennganhmienphi">Tài liệu chuyên ngành miễn phí</a></blockquote></div>
