			<!-- Page Header -->
			<div class="page-header">
				<div class="container">
					<div class="row">
						<div class="col-md-10">
							<ul class="page-header-breadcrumb">
								<li><a href="{{ \Constant::URL_HOME }}">Home</a></li>
								<li>{{ $cat->cat_name }}</li>
							</ul>
							<h1>{{ $cat->cat_name }}</h1>
							<small>{{ $cat->cat_description }}</small>
						</div>
					</div>
				</div>
			</div>
			<!-- /Page Header -->