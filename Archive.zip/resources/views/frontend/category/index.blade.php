@extends('frontend.front_layouts')
@section('content')
	@include('frontend.category.breadcrum')
	@include('frontend.category.content')
@endsection