			<!-- Page Header -->
			<div class="page-header">
				<div class="container">
					<div class="row">
						<div class="col-md-10">
							<h1>{{ $filter }}</h1>
							<small>Kết quả tìm kiếm</small>
						</div>
					</div>
				</div>
			</div>
			<!-- /Page Header -->