@extends('frontend.front_layouts')
@section('content')
	@include('frontend.hashtag.breadcrum')
	@include('frontend.hashtag.content')
@endsection