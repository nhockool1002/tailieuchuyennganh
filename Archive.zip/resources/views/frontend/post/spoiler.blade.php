@if ($posts->category->cat_name == "#Music")
        <div class="col-sm-12">
            <img src="https://tinyurl.com/y7yyy23z" width="100%">
        </div>
@endif
<div style="clear: both;"></div>
<div class="spoiler">
<div class="spoiler-title">
<div class="spoiler-toggle hide-icon">&nbsp;</div>
<span style="font-size:16px"><span style="color:#660099">HƯỚNG DẪN TẢI VỀ</span></span></div>

<div class="spoiler-content" style="display: none;">
<p>Xin lỗi vì sự bất tiện khi liên kết tải về có gắng quảng cáo, mong các bạn thông cảm vì đây là một phần chi phí duy trì cũng như để dành mua các tài liệu - khóa học cho mọi người. Các bạn thông cảm cho&nbsp;<strong><span style="color:#c0392b">XShare</span>&nbsp;</strong>nhé.</p>

<p><span style="color:#27ae60"><span style="font-size:16px"><strong>Bước 1</strong></span></span>&nbsp;: Các bạn nhấn vào liên kết tải bên dưới, trang web hiện ra và các bạn làm như hình bên dươi.</p>

<p style="text-align:center"><img alt="" src="https://tailieuchuyennganh.com/img/hddl.gif"></p>

<p><span style="color:#27ae60"><span style="font-size:16px"><strong>Bước 2</strong></span></span>&nbsp;:&nbsp;Sau khi vượt qua bước trên các bạn sẽ được di chuyển tới trang&nbsp;<strong>download</strong>, các bạn lưu ý đây là trang tải về có tốc độ ngang với Google Drive,&nbsp;<strong>XShare&nbsp;</strong>xin đảm bảo sẽ không Popup hay bất kỳ quảng cáo khó chiệu nào xuất hiện . Các bạn làm như hình dưới.</p>

<p style="text-align:center"><img alt="" src="https://tinyurl.com/yd9ymsow"></p>
</div>
</div>