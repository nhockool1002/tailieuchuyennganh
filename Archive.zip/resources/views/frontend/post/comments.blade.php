                            
							<div class="fb-comments" data-href="{{ url()->current() }}" data-numposts="5" width="100%"></div>
