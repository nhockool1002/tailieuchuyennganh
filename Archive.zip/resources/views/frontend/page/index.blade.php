@extends('frontend.front_layouts')
@section('content')
	@include('frontend.page.header-page')
	@include('frontend.page.content')
@endsection