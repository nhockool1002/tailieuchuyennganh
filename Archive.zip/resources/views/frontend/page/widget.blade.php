						<!-- ad -->
						<div class="aside-widget text-center">
							@include('frontend.ads.ads-right-widget-post')
						</div>
						<!-- /ad -->

						<!-- post widget -->
						<div class="aside-widget">
							@include('frontend.page.right-widget-post-1')
						</div>
						<!-- /post widget -->

						<!-- post widget -->
						<div class="aside-widget">
							@include('frontend.page.right-widget-post-2')
						</div>
						<!-- /post widget -->
						
						<!-- catagories -->
						<div class="aside-widget">
							@include('common.front.widget-list-category')
						</div>
						<!-- /catagories -->
						
						<!-- tags -->
						<div class="aside-widget">
							@include('common.front.widget-list-tags')
						</div>
						<!-- /tags -->
						
						<!-- archive -->
						<div class="aside-widget">
							@include('common.front.widget-list-archive')
						</div>
						<!-- /archive -->