							<div class="section-title">
								<h2>Send me contact</h2>
								<p>comments system has been disabled to construct, in this time you can send contact for author *</p>
							</div>
							<form class="post-reply">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<span>Name *</span>
											<input class="input" type="text" name="name" disabled>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<span>Email *</span>
											<input class="input" type="email" name="email" disabled>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<span>Website</span>
											<input class="input" type="text" name="website" disabled>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<textarea class="input" name="message" placeholder="Message" disabled></textarea>
										</div>
										<button class="primary-button" disabled>Submit</button>
									</div>
								</div>
							</form>
