<!-- section -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-8">
						<div class="row">							
							<div class="clearfix visible-md visible-lg"></div>						
							<!-- ad -->
							<div class="col-md-12">
								<div class="section-row">
									@include('frontend.ads.ads-top-content-category')
								</div>
							</div>
							<!-- ad -->
							@include('frontend.donate.listpost')
						</div>
					</div>
					
					<div class="col-md-4">
						@include('frontend.donate.widget')
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /section -->