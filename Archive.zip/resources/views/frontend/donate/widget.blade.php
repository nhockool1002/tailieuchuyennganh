						<!-- ad -->
						<div class="aside-widget text-center">
							<!-- Composite Start -->
							<div class="fb-page" data-href="https://www.facebook.com/tailieuchuyennganhmienphi" data-tabs="" data-width="" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/tailieuchuyennganhmienphi" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/tailieuchuyennganhmienphi">Tài liệu chuyên ngành miễn phí</a></blockquote></div>
							<!-- Composite End -->
							{{-- @include('frontend.ads.ads-right-widget-category') --}}
						</div>
						<!-- /ad -->
						
						<!-- post widget -->
						<div class="aside-widget">
							@include('frontend.donate.right-widget-category-1-mostpostincat')
						</div>
						<!-- /post widget -->
						
						<!-- catagories -->
						<div class="aside-widget">
							@include('common.front.widget-list-category')
						</div>
						<!-- /catagories -->
						
						<!-- tags -->
						<div class="aside-widget">
							@include('common.front.widget-list-tags')
						</div>
						<!-- /tags -->
						
						<!-- archive -->
						<div class="aside-widget">
							@include('common.front.widget-list-archive')
						</div>
						<!-- /archive -->
