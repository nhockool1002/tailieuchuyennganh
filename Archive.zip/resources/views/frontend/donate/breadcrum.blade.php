			<!-- Page Header -->
			<div class="page-header">
				<div class="container">
					<div class="row">
						<div class="col-md-10">
							<ul class="page-header-breadcrumb">
								<li><a href="{{ \Constant::URL_HOME }}">Home</a></li>
								<li>XShare Online</li>
							</ul>
							<h1>XShare Online</h1>
							<small>Xem Online Tất cả khóa học tại XShare Community mà không cần tải về</small>
						</div>
					</div>
				</div>
			</div>
			<!-- /Page Header -->