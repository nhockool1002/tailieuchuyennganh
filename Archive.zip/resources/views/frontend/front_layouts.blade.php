@include('common.front.header')
@include('common.front.menu')
@include('common.front.nav-aside')
@yield('content')
<a href="#" class="scrollToTop"></a>
@include('common.front.footer')

