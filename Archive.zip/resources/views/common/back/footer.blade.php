</div>

</body>

    <!--   Core JS Files   -->
    <script src="{{ asset('admin-assets/js/jquery-1.10.2.js') }}" type="text/javascript"></script>
	<script src="{{ asset('admin-assets/js/bootstrap.min.js') }}" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="{{ asset('admin-assets/js/bootstrap-checkbox-radio.js') }}"></script>

    <!--  Notifications Plugin    -->
    <script src="{{ asset('admin-assets/js/bootstrap-notify.js') }}"></script>

    <!--  Google Maps Plugin    -->
    <!-- <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script> -->

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="{{ asset('admin-assets/js/paper-dashboard.js') }}"></script>

    @stack('scripts')
    <!-- CUSTOM CSS -->
    <script src="{{ asset('admin-assets/js/script.js') }}"></script>
</html>
